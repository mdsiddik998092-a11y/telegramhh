#!/usr/bin/env python3
"""
টেলিগ্রাম ভিডিও ডাউনলোড বট
YouTube, Facebook, TikTok, Instagram, Twitter সহ ১০০০+ সাইট সাপোর্ট করে।
"""

import logging
import os
import asyncio
import tempfile
from telegram import Update, ReplyKeyboardRemove
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
import yt_dlp

# ─────────────────────────────────────────────
# কনফিগারেশন
# ─────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = "8749138581:AAE7-gk8Ew17g3QjiGC-ukupd9srDBYo"
ADMIN_ID           = 8528931469

# শুধু অনুমোদিত ইউজার ব্যবহার করতে পারবে (খালি রাখলে সবাই পারবে)
ALLOWED_USER_IDS = []  # উদাহরণ: [123456, 789012]

MAX_FILE_SIZE_MB = 50  # Telegram বিনামূল্যে সর্বোচ্চ ৫০ MB পাঠাতে পারে

# ─────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def is_allowed(user_id: int) -> bool:
    if not ALLOWED_USER_IDS:
        return True
    return user_id in ALLOWED_USER_IDS


# ─────────────────────────────────────────────
# /start
# ─────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update.effective_user.id):
        await update.message.reply_text("❌ আপনার অনুমতি নেই।")
        return

    await update.message.reply_text(
        "🎬 *ভিডিও ডাউনলোড বটে স্বাগতম!*\n\n"
        "যেকোনো ভিডিও লিংক পাঠান — আমি ডাউনলোড করে দেব।\n\n"
        "✅ সাপোর্টেড: YouTube, Facebook, TikTok, Instagram, Twitter/X, Vimeo এবং আরও ১০০০+ সাইট\n\n"
        "📌 কমান্ডসমূহ:\n"
        "/start — শুরু\n"
        "/help — সাহায্য\n"
        "/audio — শুধু অডিও (MP3) ডাউনলোড\n",
        parse_mode="Markdown",
    )


# ─────────────────────────────────────────────
# /help
# ─────────────────────────────────────────────
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "📖 *ব্যবহার নির্দেশিকা:*\n\n"
        "1️⃣ ভিডিও লিংক সরাসরি পাঠান → ভিডিও পাবেন\n"
        "2️⃣ /audio লিখে তারপর লিংক পাঠান → MP3 পাবেন\n\n"
        "⚠️ *সীমাবদ্ধতা:*\n"
        f"• সর্বোচ্চ {MAX_FILE_SIZE_MB} MB ফাইল পাঠানো যাবে\n"
        "• বড় ভিডিও হলে কম মান (quality) নির্বাচন হবে\n\n"
        "🌐 *সাপোর্টেড সাইট:* YouTube, TikTok, Facebook, Instagram, Twitter/X, Vimeo, Dailymotion এবং আরও অনেক।",
        parse_mode="Markdown",
    )


# ─────────────────────────────────────────────
# ভিডিও ডাউনলোড ফাংশন
# ─────────────────────────────────────────────
def download_video(url: str, output_dir: str, audio_only: bool = False) -> dict:
    """yt-dlp দিয়ে ভিডিও ডাউনলোড করে ফাইল পাথ রিটার্ন করে।"""

    result = {"success": False, "filepath": None, "title": "", "error": ""}

    if audio_only:
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(output_dir, "%(title).50s.%(ext)s"),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
            "quiet": True,
            "no_warnings": True,
        }
    else:
        ydl_opts = {
            # ৫০MB এর মধ্যে সেরা মান
            "format": f"best[filesize<{MAX_FILE_SIZE_MB}M]/bestvideo[filesize<{MAX_FILE_SIZE_MB}M]+bestaudio/best",
            "outtmpl": os.path.join(output_dir, "%(title).50s.%(ext)s"),
            "merge_output_format": "mp4",
            "quiet": True,
            "no_warnings": True,
        }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            title = info.get("title", "ভিডিও")

            # ডাউনলোড হওয়া ফাইল খোঁজা
            for fname in os.listdir(output_dir):
                fpath = os.path.join(output_dir, fname)
                if os.path.isfile(fpath):
                    result["success"] = True
                    result["filepath"] = fpath
                    result["title"] = title
                    break

    except yt_dlp.utils.DownloadError as e:
        result["error"] = str(e)
    except Exception as e:
        result["error"] = str(e)

    return result


# ─────────────────────────────────────────────
# URL বার্তা হ্যান্ডলার (ভিডিও)
# ─────────────────────────────────────────────
async def handle_url(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update.effective_user.id):
        await update.message.reply_text("❌ আপনার অনুমতি নেই।")
        return

    url = update.message.text.strip()

    # URL কিনা যাচাই
    if not (url.startswith("http://") or url.startswith("https://")):
        await update.message.reply_text(
            "⚠️ সঠিক ভিডিও লিংক পাঠান।\nউদাহরণ: https://www.youtube.com/watch?v=..."
        )
        return

    status_msg = await update.message.reply_text("⏳ ডাউনলোড হচ্ছে, একটু অপেক্ষা করুন...")

    with tempfile.TemporaryDirectory() as tmpdir:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, download_video, url, tmpdir, False)

        if not res["success"]:
            await status_msg.edit_text(
                f"❌ ডাউনলোড ব্যর্থ হয়েছে!\n\nকারণ: {res['error'][:200]}"
            )
            return

        filepath = res["filepath"]
        title    = res["title"]
        filesize = os.path.getsize(filepath) / (1024 * 1024)

        if filesize > MAX_FILE_SIZE_MB:
            await status_msg.edit_text(
                f"❌ ফাইলটি অনেক বড় ({filesize:.1f} MB)।\n"
                f"Telegram সর্বোচ্চ {MAX_FILE_SIZE_MB} MB সাপোর্ট করে।"
            )
            return

        await status_msg.edit_text(f"📤 পাঠানো হচ্ছে: *{title}*", parse_mode="Markdown")

        try:
            with open(filepath, "rb") as f:
                await update.message.reply_video(
                    video=f,
                    caption=f"🎬 {title}\n\n📥 @{(await context.bot.get_me()).username}",
                    supports_streaming=True,
                )
            await status_msg.delete()
        except Exception as e:
            await status_msg.edit_text(f"❌ ফাইল পাঠাতে সমস্যা হয়েছে:\n{str(e)[:200]}")


# ─────────────────────────────────────────────
# /audio কমান্ড
# ─────────────────────────────────────────────
async def audio_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed(update.effective_user.id):
        await update.message.reply_text("❌ আপনার অনুমতি নেই।")
        return

    # /audio এর পরে URL থাকলে সেটা নেওয়া
    args = context.args
    if not args:
        await update.message.reply_text(
            "📎 ব্যবহার: `/audio <লিংক>`\nউদাহরণ: `/audio https://youtu.be/xyz`",
            parse_mode="Markdown",
        )
        return

    url = args[0].strip()
    if not (url.startswith("http://") or url.startswith("https://")):
        await update.message.reply_text("⚠️ সঠিক লিংক দিন।")
        return

    status_msg = await update.message.reply_text("🎵 অডিও ডাউনলোড হচ্ছে...")

    with tempfile.TemporaryDirectory() as tmpdir:
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, download_video, url, tmpdir, True)

        if not res["success"]:
            await status_msg.edit_text(f"❌ ডাউনলোড ব্যর্থ!\n{res['error'][:200]}")
            return

        filepath = res["filepath"]
        title    = res["title"]
        filesize = os.path.getsize(filepath) / (1024 * 1024)

        if filesize > MAX_FILE_SIZE_MB:
            await status_msg.edit_text(f"❌ ফাইল অনেক বড় ({filesize:.1f} MB)।")
            return

        await status_msg.edit_text(f"📤 পাঠানো হচ্ছে: *{title}*", parse_mode="Markdown")

        try:
            with open(filepath, "rb") as f:
                await update.message.reply_audio(
                    audio=f,
                    caption=f"🎵 {title}",
                    title=title,
                )
            await status_msg.delete()
        except Exception as e:
            await status_msg.edit_text(f"❌ ফাইল পাঠাতে সমস্যা:\n{str(e)[:200]}")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────
def main() -> None:
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("audio", audio_command))

    # URL বার্তা হ্যান্ডলার
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url))

    logger.info("ভিডিও ডাউনলোড বট চালু হচ্ছে...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
